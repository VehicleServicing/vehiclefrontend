import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../shared/user.service';
import { User } from '../../user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: User = new User();
  errorMessage: string;

  constructor(public userService: UserService, public router: Router) {
  }

  ngOnInit() {
  }

  register() {
  this.userService.createAccount(this.user)
  .subscribe(
    data=> {console.log(data); 
      this.router.navigate(['/login']);},
    error =>{
    console.error(error)
    this.errorMessage = "username already exist";
    })
  // console.log(JSON.stringify(this.registerForm.value));
}
}
