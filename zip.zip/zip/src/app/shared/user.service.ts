import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { User } from '../user';
import { Http } from '@angular/http';
import { AppComponent } from '../app.component';
import { TokenService } from './token.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(public http: Http, private tokenService : TokenService) { 

  }

  createAccount( user:User ){
    return this.http.post(AppComponent.API_URL+'/account/register',user)
      .map(resp=>resp.json());
  }
  
  isLoggedIn() {
    if (this.tokenService.GetToken()){
return true;
    }
    return false;
  }
}