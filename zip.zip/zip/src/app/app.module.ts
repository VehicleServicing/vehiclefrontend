import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//forms
import { ReactiveFormsModule, FormsModule } from '@angular/forms';


//http
import { HttpClientModule } from '@angular/common/http';
import {HttpModule} from "@angular/http";
import { map } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ContactsComponent } from './contacts/contacts.component';
import { LoginComponent } from './user/login/login.component';
import { RegisterComponent } from './user/register/register.component';
import { ProfileComponent } from './user/profile/profile.component';
import { AuthService } from './shared/auth.service';
import { UserService } from './shared/user.service';
import { AuthGuard } from './shared/auth.guard';
import { AdminComponent } from './admin/admin.component';
import { TokenService } from './shared/token.service';
import { AboutUsComponent } from './about-us/about-us.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    ContactsComponent,
    LoginComponent,
    RegisterComponent,
    ProfileComponent,
    AdminComponent,
    AboutUsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpModule
  ],
  providers: [AuthService, UserService, AuthGuard, TokenService, CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
